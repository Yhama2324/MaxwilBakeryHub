import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { ShoppingCart as CartIcon, Plus, Minus, Trash2 } from "lucide-react";

interface CartItem {
  id: number;
  name: string;
  price: string;
  quantity: number;
  imageUrl?: string;
}

interface ShoppingCartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: number, change: number) => void;
  onRemoveItem: (productId: number) => void;
  onCheckout: () => void;
  total: number;
}

export default function ShoppingCart({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  total
}: ShoppingCartProps) {
  const formatPrice = (price: string | number) => {
    return `₱${parseFloat(price.toString()).toFixed(2)}`;
  };

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md flex flex-col h-full">
        <SheetHeader className="flex-shrink-0">
          <SheetTitle className="flex items-center space-x-2">
            <CartIcon className="h-5 w-5" />
            <span>Shopping Cart</span>
            {itemCount > 0 && (
              <Badge className="bg-bakery-primary">
                {itemCount}
              </Badge>
            )}
          </SheetTitle>
          <SheetDescription>
            Review your items before checkout
          </SheetDescription>
        </SheetHeader>

        <div className="flex flex-col flex-1 min-h-0">
          <div className="flex-1 overflow-y-auto py-4 min-h-0 scrollbar-hide">
            {items.length === 0 ? (
              <div className="text-center py-12">
                <CartIcon className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Your cart is empty</h3>
                <p className="text-gray-500">Add some delicious items to get started!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center space-x-2 p-2 border rounded-lg">
                    <img
                      src={item.imageUrl || "https://via.placeholder.com/40x40?text=No+Image"}
                      alt={item.name}
                      className="w-10 h-10 object-cover rounded flex-shrink-0"
                      onError={(e) => {
                        e.currentTarget.src = "https://via.placeholder.com/40x40?text=No+Image";
                      }}
                    />
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-xs text-bakery-dark truncate">{item.name}</h4>
                      <p className="text-xs text-bakery-primary font-semibold">
                        {formatPrice(item.price)}
                      </p>
                    </div>

                    <div className="flex items-center space-x-1 flex-shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-6 h-6 p-0"
                        onClick={() => onUpdateQuantity(item.id, -1)}
                      >
                        <Minus className="h-2 w-2" />
                      </Button>
                      
                      <span className="w-6 text-center text-xs font-medium">
                        {item.quantity}
                      </span>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-6 h-6 p-0"
                        onClick={() => onUpdateQuantity(item.id, 1)}
                      >
                        <Plus className="h-2 w-2" />
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-6 h-6 p-0 text-red-500 hover:text-red-700"
                        onClick={() => onRemoveItem(item.id)}
                      >
                        <Trash2 className="h-2 w-2" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {items.length > 0 && (
            <div className="flex-shrink-0 border-t pt-4 pb-2 space-y-4">
              <Separator />
              
              <div className="flex items-center justify-between text-lg font-semibold">
                <span className="text-bakery-dark">Total:</span>
                <span className="text-bakery-primary">{formatPrice(total)}</span>
              </div>

              <Button
                onClick={onCheckout}
                className="w-full bg-bakery-primary hover:bg-bakery-secondary text-white font-semibold py-3 transform hover:scale-105 active:scale-95 transition-all duration-200"
                size="lg"
              >
                Proceed to Checkout
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
