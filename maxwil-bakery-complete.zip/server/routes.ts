import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertProductSchema, insertOrderSchema } from "@shared/schema";
import { z } from "zod";

export function registerRoutes(app: Express): Server {
  // sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.post("/api/products", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== "admin") {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== "admin") {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const productId = parseInt(req.params.id);
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.updateProduct(productId, validatedData);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== "admin") {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const productId = parseInt(req.params.id);
      const deleted = await storage.deleteProduct(productId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Order routes
  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== "admin") {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      // Sanitize and validate order data
      const {
        customerName,
        customerPhone,
        deliveryAddress,
        paymentMethod,
        totalAmount,
        items
      } = req.body;

      // Input sanitization
      const sanitizedData = {
        customerName: customerName?.trim().slice(0, 100),
        customerPhone: customerPhone?.replace(/[^\d+\s()-]/g, '').trim(),
        deliveryAddress: deliveryAddress?.trim().slice(0, 500),
        paymentMethod: ["cod", "gcash", "bank"].includes(paymentMethod) ? paymentMethod : "cod",
        totalAmount: Math.max(0, parseFloat(totalAmount) || 0).toFixed(2),
        items: typeof items === 'string' ? items : JSON.stringify(items || [])
      };

      // Validate required fields
      if (!sanitizedData.customerName || sanitizedData.customerName.length < 2) {
        return res.status(400).json({ message: "Valid customer name is required" });
      }

      if (!sanitizedData.customerPhone || sanitizedData.customerPhone.length < 10) {
        return res.status(400).json({ message: "Valid phone number is required" });
      }

      if (!sanitizedData.deliveryAddress || sanitizedData.deliveryAddress.length < 10) {
        return res.status(400).json({ message: "Complete delivery address is required" });
      }

      // Validate items and total amount
      let parsedItems = [];
      try {
        parsedItems = JSON.parse(sanitizedData.items);
      } catch {
        return res.status(400).json({ message: "Invalid order items" });
      }

      if (!Array.isArray(parsedItems) || parsedItems.length === 0) {
        return res.status(400).json({ message: "Order must contain at least one item" });
      }

      // Extract coordinates if provided from the request body
      const { coordinates } = req.body;
      const orderData = {
        customerName: sanitizedData.customerName,
        customerPhone: sanitizedData.customerPhone,
        deliveryAddress: sanitizedData.deliveryAddress,
        paymentMethod: sanitizedData.paymentMethod,
        totalAmount: sanitizedData.totalAmount,
        items: sanitizedData.items,
        deliveryLatitude: coordinates?.lat ? coordinates.lat.toString() : null,
        deliveryLongitude: coordinates?.lng ? coordinates.lng.toString() : null
      };
      
      const validatedData = insertOrderSchema.parse(orderData);
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error) {
      console.error("Order creation error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order", error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put("/api/orders/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || req.user?.role !== "admin") {
      return res.status(401).json({ message: "Admin access required" });
    }

    try {
      const orderId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !["pending", "accepted", "preparing", "delivered", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      const order = await storage.updateOrderStatus(orderId, status);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
